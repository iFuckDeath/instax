#!/bin/bash

# Instagram Reels Viewer - Quick Install Script
# For Ubuntu 20.04+ VPS

set -e

echo "🚀 Instagram Reels Viewer - Installation"
echo "========================================"
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "❌ Please run as root: sudo ./install.sh"
    exit 1
fi

# Update system
echo "📦 Updating system packages..."
apt update -qq
apt upgrade -y -qq

# Install Node.js
echo "📦 Installing Node.js 18..."
if ! command -v node &> /dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
    apt install -y nodejs
fi
echo "✅ Node.js $(node -v) installed"

# Install Python
echo "📦 Installing Python 3..."
apt install -y python3 python3-pip
echo "✅ Python $(python3 --version) installed"

# Install Docker (optional)
echo "📦 Installing Docker..."
if ! command -v docker &> /dev/null; then
    curl -fsSL https://get.docker.com | sh
    systemctl enable docker
    systemctl start docker
fi
echo "✅ Docker installed"

# Install Docker Compose
echo "📦 Installing Docker Compose..."
if ! command -v docker-compose &> /dev/null; then
    curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
fi
echo "✅ Docker Compose installed"

# Install PM2 (alternative to Docker)
echo "📦 Installing PM2..."
npm install -g pm2
echo "✅ PM2 installed"

# Install project dependencies
echo "📦 Installing project dependencies..."
npm install
pip3 install -r requirements.txt
echo "✅ Dependencies installed"

# Create necessary directories
echo "📁 Creating directories..."
mkdir -p videos sessions logs
echo "✅ Directories created"

# Setup environment file
if [ ! -f .env ]; then
    echo "📝 Creating .env file..."
    cp .env.example .env
    echo "⚠️  Please edit .env file with your credentials:"
    echo "   nano .env"
else
    echo "✅ .env file already exists"
fi

# Setup firewall
echo "🔥 Configuring firewall..."
if command -v ufw &> /dev/null; then
    ufw allow 22
    ufw allow 80
    ufw allow 443
    ufw allow 3000
    echo "y" | ufw enable
    echo "✅ Firewall configured"
fi

echo ""
echo "✅ Installation Complete!"
echo ""
echo "📋 Next Steps:"
echo "1. Edit .env file with your Telegram bot credentials:"
echo "   nano .env"
echo ""
echo "2. Start the system:"
echo "   Option A (Docker):"
echo "   docker-compose up -d"
echo ""
echo "   Option B (PM2):"
echo "   pm2 start server.js --name reels-web"
echo "   pm2 start downloader.js --name reels-downloader"
echo "   pm2 start bot.py --name reels-bot --interpreter python3"
echo "   pm2 save"
echo ""
echo "3. Add Instagram accounts via Telegram bot:"
echo "   /add_account username password"
echo ""
echo "4. Access your site:"
echo "   http://$(hostname -I | awk '{print $1}'):3000"
echo ""
echo "📖 Full guide: cat SETUP_GUIDE.md"
echo ""
