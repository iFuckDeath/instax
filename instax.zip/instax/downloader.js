// Instagram Reels Downloader
// Runs 24/7 to keep cache full

const { IgApiClient } = require('instagram-private-api');
const fs = require('fs-extra');
const path = require('path');
const axios = require('axios');

const CONFIG_FILE = 'config.json';
const VIDEO_DIR = 'videos';
const SESSION_DIR = 'sessions';

let config = {};
let currentAccountIndex = 0;
let isRunning = false;

// Load configuration
function loadConfig() {
    try {
        config = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
    } catch (e) {
        console.error('Failed to load config:', e);
        config = { accounts: [], proxies: [], proxy_enabled: false, settings: {} };
    }
}

// Save configuration
function saveConfig() {
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
}

// Get next account (rotation)
function getNextAccount() {
    if (!config.accounts || config.accounts.length === 0) {
        return null;
    }
    
    const account = config.accounts[currentAccountIndex];
    currentAccountIndex = (currentAccountIndex + 1) % config.accounts.length;
    return account;
}

// Get Instagram client with session
async function getClient(username, password) {
    const ig = new IgApiClient();
    
    // Setup device
    ig.state.generateDevice(username);
    
    // Load proxy if enabled
    if (config.proxy_enabled && config.proxies && config.proxies.length > 0) {
        const proxy = config.proxies[Math.floor(Math.random() * config.proxies.length)];
        if (proxy.url) {
            // Setup proxy (simplified - would need proper implementation)
            console.log(`Using proxy: ${proxy.url}`);
        }
    }
    
    try {
        // Try to load session
        const sessionFile = path.join(SESSION_DIR, `${username}.json`);
        if (fs.existsSync(sessionFile)) {
            const session = JSON.parse(fs.readFileSync(sessionFile, 'utf8'));
            await ig.state.deserialize(session);
            console.log(`Loaded session for ${username}`);
        } else {
            // Login
            await ig.account.login(username, password);
            
            // Save session
            const state = await ig.state.serialize();
            fs.writeFileSync(sessionFile, JSON.stringify(state));
            console.log(`New session created for ${username}`);
        }
        
        return ig;
    } catch (error) {
        console.error(`Login failed for ${username}:`, error.message);
        throw error;
    }
}

// Download video from URL
async function downloadVideo(url, filename) {
    try {
        const response = await axios({
            method: 'GET',
            url: url,
            responseType: 'stream',
            timeout: 30000
        });
        
        const writer = fs.createWriteStream(path.join(VIDEO_DIR, filename));
        response.data.pipe(writer);
        
        return new Promise((resolve, reject) => {
            writer.on('finish', resolve);
            writer.on('error', reject);
        });
    } catch (error) {
        console.error(`Download failed for ${filename}:`, error.message);
        throw error;
    }
}

// Fetch and download trending reels
async function downloadReels() {
    const account = getNextAccount();
    if (!account) {
        console.log('No accounts configured');
        return 0;
    }
    
    try {
        console.log(`Using account: ${account.username}`);
        const ig = await getClient(account.username, account.password);
        
        // Get trending reels
        const timelineFeed = ig.feed.timeline();
        const items = await timelineFeed.items();
        
        let downloaded = 0;
        
        for (const item of items) {
            // Only process reels/videos
            if (item.media_type !== 2 || !item.video_versions) continue;
            
            // Get video URL (best quality)
            const videoUrl = item.video_versions[0].url;
            const videoId = item.id.split('_')[0];
            const filename = `${videoId}.mp4`;
            const filepath = path.join(VIDEO_DIR, filename);
            
            // Skip if already downloaded
            if (fs.existsSync(filepath)) {
                continue;
            }
            
            // Download
            console.log(`Downloading: ${filename}`);
            await downloadVideo(videoUrl, filename);
            downloaded++;
            
            // Stop if cache is full
            const videoCount = fs.readdirSync(VIDEO_DIR).filter(f => f.endsWith('.mp4')).length;
            const maxCache = config.settings.max_cache || 100;
            
            if (videoCount >= maxCache) {
                console.log('Cache full, stopping');
                break;
            }
            
            // Small delay between downloads
            await new Promise(resolve => setTimeout(resolve, 2000));
        }
        
        console.log(`Downloaded ${downloaded} new reels`);
        return downloaded;
        
    } catch (error) {
        console.error('Download error:', error.message);
        return 0;
    }
}

// Clean up old videos
function cleanupOldVideos() {
    try {
        const videos = fs.readdirSync(VIDEO_DIR)
            .filter(f => f.endsWith('.mp4'))
            .map(f => ({
                name: f,
                path: path.join(VIDEO_DIR, f),
                mtime: fs.statSync(path.join(VIDEO_DIR, f)).mtime
            }))
            .sort((a, b) => b.mtime - a.mtime);
        
        const maxAge = (config.settings.auto_delete_minutes || 10) * 60 * 1000;
        const now = Date.now();
        
        let deleted = 0;
        for (const video of videos) {
            const age = now - video.mtime.getTime();
            if (age > maxAge) {
                fs.unlinkSync(video.path);
                deleted++;
            }
        }
        
        if (deleted > 0) {
            console.log(`Cleaned up ${deleted} old videos`);
        }
    } catch (error) {
        console.error('Cleanup error:', error.message);
    }
}

// Main download loop
async function mainLoop() {
    console.log('Downloader started');
    isRunning = true;
    
    while (isRunning) {
        try {
            loadConfig();
            
            // Check cache size
            const videoCount = fs.readdirSync(VIDEO_DIR).filter(f => f.endsWith('.mp4')).length;
            const minCache = config.settings.min_cache || 50;
            
            console.log(`Current cache: ${videoCount} videos (minimum: ${minCache})`);
            
            // Download if below minimum
            if (videoCount < minCache) {
                console.log('Cache below minimum, downloading...');
                await downloadReels();
            } else {
                console.log('Cache OK, waiting...');
            }
            
            // Cleanup old videos
            cleanupOldVideos();
            
            // Wait before next check
            const interval = (config.settings.download_interval_seconds || 60) * 1000;
            await new Promise(resolve => setTimeout(resolve, interval));
            
        } catch (error) {
            console.error('Main loop error:', error.message);
            await new Promise(resolve => setTimeout(resolve, 10000));
        }
    }
}

// Start downloader
if (require.main === module) {
    // Ensure directories exist
    fs.ensureDirSync(VIDEO_DIR);
    fs.ensureDirSync(SESSION_DIR);
    
    console.log('Instagram Reels Downloader');
    console.log('Press Ctrl+C to stop');
    
    mainLoop().catch(console.error);
    
    // Graceful shutdown
    process.on('SIGINT', () => {
        console.log('\nStopping downloader...');
        isRunning = false;
        process.exit(0);
    });
}

module.exports = { downloadReels, cleanupOldVideos };
