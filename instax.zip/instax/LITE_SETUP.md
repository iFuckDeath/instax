# 🪶 Lightweight Setup for 1GB RAM VPS

## Your VPS Specs:
- 1 Core CPU
- 1GB RAM
- 30GB Storage
- Unlimited Bandwidth

**Can it run? YES! With optimizations.** ✅

---

## 🎯 Optimizations Made:

### 1. Single Container (saves ~300MB RAM)
Instead of 3 containers, everything runs in 1 container.

### 2. Lower Cache Settings
```json
min_cache: 20   (instead of 50)
max_cache: 40   (instead of 100)
video_quality: 720p (instead of 1080p)
auto_delete: 5 min (instead of 10 min)
```

### 3. Alpine Linux Base
Smaller Docker image (~100MB vs ~500MB)

### 4. Memory Limit
Container limited to 900MB (leaves 100MB for system)

---

## 🚀 Installation Steps

### Step 1: Connect to VPS
```bash
ssh root@your-vps-ip
```

### Step 2: Free Up RAM
```bash
# Stop unnecessary services
systemctl stop snapd
systemctl disable snapd

# Clear cache
sync; echo 3 > /proc/sys/vm/drop_caches
```

### Step 3: Install Docker
```bash
# Update
apt update && apt upgrade -y

# Install Docker
curl -fsSL https://get.docker.com | sh
systemctl enable docker
systemctl start docker
```

### Step 4: Install Docker Compose
```bash
curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose
```

### Step 5: Upload & Extract Files
```bash
cd /root
# Upload instagram-reel-viewer.tar.gz
tar -xzf instagram-reel-viewer.tar.gz
cd instagram-reel-viewer
```

### Step 6: Use Lite Configuration
```bash
# Use lightweight config
cp config-lite.json config.json

# Configure environment
cp .env.example .env
nano .env
```

**Edit .env with your bot credentials, then save (Ctrl+X, Y, Enter)**

### Step 7: Start with Lite Docker Compose
```bash
# Use lite version
docker-compose -f docker-compose-lite.yml up -d
```

**This will:**
- Build smaller image (~200MB)
- Use less RAM (~700-800MB)
- Keep smaller cache (20-40 videos)

### Step 8: Check Status
```bash
docker-compose -f docker-compose-lite.yml ps
docker stats  # Monitor RAM usage
```

### Step 9: Configure Bot & Add Accounts
Same as before:
```
/start
/add_account username password
```

---

## 📊 Expected Performance

**RAM Usage:**
- Docker: ~600-700MB
- System: ~100MB
- Free: ~200MB

**Storage:**
- Videos (20-40): ~2-4GB
- System: ~2GB
- Free: ~24GB

**Performance:**
- Loading: Slightly slower (1-2 seconds)
- Scrolling: Smooth
- Downloads: ~1 video every 2 minutes

---

## 🔧 Additional Optimizations

### 1. Swap File (Recommended)
Add 1GB swap to help with memory spikes:

```bash
# Create 1GB swap
fallocate -l 1G /swapfile
chmod 600 /swapfile
mkswap /swapfile
swapon /swapfile

# Make permanent
echo '/swapfile none swap sw 0 0' >> /etc/fstab

# Verify
free -h
```

**Now you have 1GB RAM + 1GB Swap = 2GB total!**

### 2. Limit Docker Logging
```bash
# Edit Docker daemon
nano /etc/docker/daemon.json
```

Add:
```json
{
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  }
}
```

Restart Docker:
```bash
systemctl restart docker
```

### 3. Cleanup Old Containers
```bash
# Remove unused images
docker system prune -a

# Remove old containers
docker container prune
```

---

## 🎛️ Runtime Settings

**In Telegram bot, adjust settings:**

```
/set_cache 15 30     # Even smaller cache
/set_quality 720p    # Lower quality = less storage
```

**Edit config.json manually:**
```bash
nano config.json
```

```json
{
  "settings": {
    "min_cache": 15,
    "max_cache": 30,
    "video_quality": "720p",
    "auto_delete_minutes": 3,
    "download_interval_seconds": 180
  }
}
```

Restart:
```bash
docker-compose -f docker-compose-lite.yml restart
```

---

## 📈 Monitoring

### Check RAM usage:
```bash
free -h
docker stats
```

### Check storage:
```bash
df -h
du -sh videos/
```

### If RAM gets full:
```bash
# Restart container
docker-compose -f docker-compose-lite.yml restart

# Clear cache
rm -rf videos/*
```

---

## ⚠️ Limitations with 1GB RAM

**Will work but:**
- ❌ Can't handle 50+ concurrent users (5-10 users OK)
- ❌ Slower downloads (1 video per 2-3 min instead of every 30 sec)
- ❌ Smaller cache (20-40 videos instead of 50-100)
- ❌ Lower quality (720p instead of 1080p)

**Still perfect for:**
- ✅ Personal use
- ✅ Small friend group (5-10 people)
- ✅ Testing/development
- ✅ Low-traffic site

---

## 🆙 Upgrade Path

**If you want better performance later:**

1. **Upgrade to 2GB RAM** (~$5-10/month)
   - Switch to full docker-compose.yml
   - Increase cache to 50-100 videos
   - Use 1080p quality

2. **Add More Storage**
   - Keep more videos cached
   - Higher quality

3. **Add More CPU Cores**
   - Faster downloads
   - Better concurrent handling

---

## 💡 Pro Tips for 1GB RAM

1. **Use swap file** (adds virtual RAM)
2. **Keep cache small** (20-30 videos max)
3. **Use 720p** (half the storage of 1080p)
4. **Quick auto-delete** (3-5 minutes)
5. **Monitor RAM regularly** (docker stats)
6. **Restart weekly** (clears memory leaks)

---

## 🚀 Quick Start Commands

```bash
# Install everything
curl -fsSL https://get.docker.com | sh
curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose

# Setup swap
fallocate -l 1G /swapfile
chmod 600 /swapfile
mkswap /swapfile
swapon /swapfile
echo '/swapfile none swap sw 0 0' >> /etc/fstab

# Extract and configure
cd /root
tar -xzf instagram-reel-viewer.tar.gz
cd instagram-reel-viewer
cp config-lite.json config.json
cp .env.example .env
nano .env  # Fill credentials

# Start!
docker-compose -f docker-compose-lite.yml up -d

# Monitor
docker stats
```

---

## ✅ Result

Your 1GB RAM VPS will run:
- ✅ Web server
- ✅ Downloader (slower but works)
- ✅ Telegram bot
- ✅ 20-40 videos cached
- ✅ Auto-delete after 5 min
- ✅ 720p quality

**Perfect for personal use!** 🎉

---

## 🆘 If It's Still Slow

**Option 1: Get 2GB RAM VPS** ($5/month)
- Much smoother
- More cache
- 1080p quality

**Option 2: Use Without Docker**
```bash
# Run directly (uses less RAM)
npm start &
node downloader.js &
python3 bot.py &
```

**Option 3: Run Only When Needed**
```bash
# Start downloader manually
docker-compose -f docker-compose-lite.yml up downloader

# Stop when cache is full
docker-compose -f docker-compose-lite.yml stop downloader
```

---

**Your VPS CAN run it! Just with lighter settings.** 💪
