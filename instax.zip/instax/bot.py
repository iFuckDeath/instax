#!/usr/bin/env python3
"""
Instagram Reels Viewer - Telegram Bot
Advanced OTP/2FA/Challenge Handler
"""

import os
import json
import asyncio
import logging
from datetime import datetime
from telethon import TelegramClient, events, Button
from instagrapi import Client
from instagrapi.exceptions import (
    TwoFactorRequired, 
    ChallengeRequired,
    LoginRequired,
    PleaseWaitFewMinutes
)
from dotenv import load_dotenv

load_dotenv()

# Configuration
BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')
API_ID = int(os.getenv('TELEGRAM_API_ID'))
API_HASH = os.getenv('TELEGRAM_API_HASH')
ADMIN_ID = int(os.getenv('ADMIN_TELEGRAM_ID'))

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/bot.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Initialize bot
bot = TelegramClient('bot_session', API_ID, API_HASH).start(bot_token=BOT_TOKEN)

# Login state management
login_states = {}

# Load/Save config
def load_config():
    try:
        with open('config.json', 'r') as f:
            return json.load(f)
    except:
        return {
            'accounts': [],
            'proxies': [],
            'proxy_enabled': False,
            'settings': {}
        }

def save_config(config):
    with open('config.json', 'w') as f:
        json.dump(config, f, indent=2)

# Instagram session management
def save_session(username, client):
    """Save Instagram session to file"""
    session_file = f'sessions/{username}.json'
    client.dump_settings(session_file)
    logger.info(f"Session saved for {username}")

def load_session(username):
    """Load Instagram session from file"""
    session_file = f'sessions/{username}.json'
    if os.path.exists(session_file):
        client = Client()
        client.load_settings(session_file)
        return client
    return None

# Authentication required check
def is_admin(event):
    return event.sender_id == ADMIN_ID

# ========== BOT COMMANDS ==========

@bot.on(events.NewMessage(pattern='/start'))
async def start_command(event):
    if not is_admin(event):
        await event.reply("⛔ Unauthorized access")
        return
    
    await event.reply(
        "🤖 **Instagram Reels Viewer Bot**\n\n"
        "**Account Management:**\n"
        "/accounts - List all accounts\n"
        "/add_account <username> <password> - Add account\n"
        "/remove_account <username> - Remove account\n"
        "/test_account <username> - Test account login\n\n"
        "**Proxy Management:**\n"
        "/proxies - List proxies\n"
        "/add_proxy <proxy_url> - Add proxy\n"
        "/remove_proxy <id> - Remove proxy\n"
        "/enable_proxy - Enable proxies\n"
        "/disable_proxy - Disable proxies\n\n"
        "**System Control:**\n"
        "/stats - System statistics\n"
        "/start_downloader - Start downloading\n"
        "/stop_downloader - Stop downloading\n"
        "/clear_cache - Delete all videos\n"
        "/logs - View recent logs\n\n"
        "**Settings:**\n"
        "/set_quality <720p|1080p> - Video quality\n"
        "/set_cache <min> <max> - Cache limits"
    )

@bot.on(events.NewMessage(pattern='/add_account'))
async def add_account(event):
    if not is_admin(event):
        return
    
    try:
        parts = event.text.split()
        if len(parts) < 3:
            await event.reply("❌ Usage: /add_account username password")
            return
        
        username = parts[1]
        password = parts[2]
        
        await event.reply(f"🔄 Attempting login for **{username}**...")
        
        # Create Instagram client
        cl = Client()
        
        # Try login
        try:
            cl.login(username, password)
            
            # Success! Save session
            save_session(username, cl)
            
            # Add to config
            config = load_config()
            config['accounts'].append({
                'username': username,
                'password': password,
                'active': True,
                'added_at': datetime.now().isoformat()
            })
            save_config(config)
            
            await event.reply(
                f"✅ **Account Added Successfully!**\n\n"
                f"Username: {username}\n"
                f"Status: Active\n"
                f"Session: Saved"
            )
            logger.info(f"Account {username} added successfully")
            
        except TwoFactorRequired:
            # 2FA required
            login_states[event.sender_id] = {
                'username': username,
                'password': password,
                'client': cl,
                'stage': '2fa_code'
            }
            
            await event.reply(
                f"🔐 **2FA Required for {username}**\n\n"
                f"Enter the 6-digit code from your authenticator app:"
            )
            
        except ChallengeRequired:
            # Challenge/Checkpoint required
            login_states[event.sender_id] = {
                'username': username,
                'password': password,
                'client': cl,
                'stage': 'challenge'
            }
            
            # Get challenge type
            challenge_data = cl.challenge_code_handler
            
            await event.reply(
                f"⚠️ **Instagram Challenge Required**\n\n"
                f"Account: {username}\n"
                f"Verification code will be sent.\n\n"
                f"Enter the verification code when received:"
            )
            
        except PleaseWaitFewMinutes:
            await event.reply(
                f"⏳ **Rate Limited**\n\n"
                f"Instagram is asking to wait. Try again in 5-10 minutes."
            )
            
        except Exception as e:
            await event.reply(f"❌ Login failed: {str(e)}")
            logger.error(f"Login error for {username}: {e}")
            
    except Exception as e:
        await event.reply(f"❌ Error: {str(e)}")

@bot.on(events.NewMessage)
async def handle_verification_codes(event):
    """Handle 2FA codes and challenge responses"""
    if not is_admin(event):
        return
    
    if event.sender_id not in login_states:
        return
    
    state = login_states[event.sender_id]
    code = event.text.strip()
    
    # Ignore if it's a command
    if code.startswith('/'):
        return
    
    try:
        if state['stage'] == '2fa_code':
            # Handle 2FA code
            username = state['username']
            password = state['password']
            
            await event.reply(f"🔄 Verifying 2FA code...")
            
            cl = Client()
            cl.login(username, password, verification_code=code)
            
            # Save session
            save_session(username, cl)
            
            # Add to config
            config = load_config()
            config['accounts'].append({
                'username': username,
                'password': password,
                'active': True,
                'added_at': datetime.now().isoformat()
            })
            save_config(config)
            
            await event.reply(
                f"✅ **2FA Verified!**\n\n"
                f"Account {username} added successfully.\n"
                f"Session saved for future use."
            )
            
            del login_states[event.sender_id]
            
        elif state['stage'] == 'challenge':
            # Handle challenge code
            username = state['username']
            cl = state['client']
            
            await event.reply(f"🔄 Verifying challenge code...")
            
            cl.challenge_code = code
            cl.challenge_code_handler(code)
            
            # Complete login
            save_session(username, cl)
            
            # Add to config
            config = load_config()
            config['accounts'].append({
                'username': username,
                'password': state['password'],
                'active': True,
                'added_at': datetime.now().isoformat()
            })
            save_config(config)
            
            await event.reply(
                f"✅ **Challenge Passed!**\n\n"
                f"Account {username} added successfully.\n"
                f"Session saved."
            )
            
            del login_states[event.sender_id]
            
    except Exception as e:
        await event.reply(
            f"❌ **Verification Failed**\n\n"
            f"Error: {str(e)}\n\n"
            f"Please try again or use /add_account to restart."
        )
        if event.sender_id in login_states:
            del login_states[event.sender_id]

@bot.on(events.NewMessage(pattern='/accounts'))
async def list_accounts(event):
    if not is_admin(event):
        return
    
    config = load_config()
    accounts = config.get('accounts', [])
    
    if not accounts:
        await event.reply("📭 No accounts configured.")
        return
    
    msg = "👥 **Instagram Accounts:**\n\n"
    for i, acc in enumerate(accounts, 1):
        status = "✅" if acc.get('active', True) else "❌"
        msg += f"{i}. {status} **{acc['username']}**\n"
    
    await event.reply(msg)

@bot.on(events.NewMessage(pattern='/remove_account'))
async def remove_account(event):
    if not is_admin(event):
        return
    
    try:
        username = event.text.split()[1]
        
        config = load_config()
        config['accounts'] = [a for a in config['accounts'] if a['username'] != username]
        save_config(config)
        
        # Remove session file
        session_file = f'sessions/{username}.json'
        if os.path.exists(session_file):
            os.remove(session_file)
        
        await event.reply(f"✅ Account **{username}** removed")
        
    except IndexError:
        await event.reply("❌ Usage: /remove_account username")

@bot.on(events.NewMessage(pattern='/stats'))
async def stats(event):
    if not is_admin(event):
        return
    
    config = load_config()
    
    # Count videos
    video_count = len([f for f in os.listdir('videos') if f.endswith('.mp4')])
    
    # Count active accounts
    active_accounts = len([a for a in config['accounts'] if a.get('active', True)])
    
    # Calculate storage
    total_size = sum(os.path.getsize(f'videos/{f}') for f in os.listdir('videos') if f.endswith('.mp4'))
    size_gb = total_size / (1024**3)
    
    msg = f"""
📊 **System Statistics**

👥 Accounts: {active_accounts}/{len(config['accounts'])}
🎥 Videos Cached: {video_count}
💾 Storage Used: {size_gb:.2f} GB
🌐 Proxies: {len(config.get('proxies', []))}
⚙️ Proxy Status: {"Enabled" if config.get('proxy_enabled') else "Disabled"}

**Settings:**
Min Cache: {config['settings'].get('min_cache', 50)}
Max Cache: {config['settings'].get('max_cache', 100)}
Quality: {config['settings'].get('video_quality', '1080p')}
"""
    
    await event.reply(msg)

@bot.on(events.NewMessage(pattern='/add_proxy'))
async def add_proxy(event):
    if not is_admin(event):
        return
    
    try:
        proxy = event.text.split()[1]
        
        config = load_config()
        config['proxies'].append({
            'url': proxy,
            'active': True
        })
        save_config(config)
        
        await event.reply(f"✅ Proxy added: {proxy}")
        
    except IndexError:
        await event.reply("❌ Usage: /add_proxy http://ip:port")

@bot.on(events.NewMessage(pattern='/proxies'))
async def list_proxies(event):
    if not is_admin(event):
        return
    
    config = load_config()
    proxies = config.get('proxies', [])
    
    if not proxies:
        await event.reply("📭 No proxies configured.")
        return
    
    msg = "🌐 **Proxies:**\n\n"
    for i, proxy in enumerate(proxies, 1):
        status = "✅" if proxy.get('active', True) else "❌"
        msg += f"{i}. {status} {proxy['url']}\n"
    
    msg += f"\n**Status:** {'Enabled' if config.get('proxy_enabled') else 'Disabled'}"
    await event.reply(msg)

@bot.on(events.NewMessage(pattern='/enable_proxy'))
async def enable_proxy(event):
    if not is_admin(event):
        return
    
    config = load_config()
    config['proxy_enabled'] = True
    save_config(config)
    
    await event.reply("✅ Proxy rotation **enabled**")

@bot.on(events.NewMessage(pattern='/disable_proxy'))
async def disable_proxy(event):
    if not is_admin(event):
        return
    
    config = load_config()
    config['proxy_enabled'] = False
    save_config(config)
    
    await event.reply("✅ Proxy rotation **disabled**")

@bot.on(events.NewMessage(pattern='/clear_cache'))
async def clear_cache(event):
    if not is_admin(event):
        return
    
    count = 0
    for file in os.listdir('videos'):
        if file.endswith('.mp4'):
            os.remove(f'videos/{file}')
            count += 1
    
    await event.reply(f"✅ Deleted {count} videos from cache")

# ========== RUN BOT ==========

async def main():
    logger.info("Starting Telegram bot...")
    try:
        await bot.run_until_disconnected()
    except KeyboardInterrupt:
        pass
    finally:
        await bot.disconnect()

if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
