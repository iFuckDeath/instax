// Instagram Reels Downloader - MIXED CONTENT
// Downloads trending reels from ALL categories

const { IgApiClient } = require('instagram-private-api');
const fs = require('fs-extra');
const path = require('path');
const axios = require('axios');

const CONFIG_FILE = 'config.json';
const VIDEO_DIR = 'videos';
const SESSION_DIR = 'sessions';

let config = {};
let currentAccountIndex = 0;
let isRunning = false;

// Popular hashtags across all categories for variety
const TRENDING_HASHTAGS = [
    'reels', 'viral', 'trending', 'explore',
    'funny', 'comedy', 'memes', 'lol',
    'dance', 'music', 'song', 'beats',
    'food', 'cooking', 'recipe', 'foodie',
    'fitness', 'workout', 'gym', 'motivation',
    'travel', 'nature', 'adventure', 'explore',
    'fashion', 'style', 'outfit', 'ootd',
    'tech', 'gadgets', 'iphone', 'android',
    'art', 'creative', 'design', 'artist',
    'pets', 'dogs', 'cats', 'animals',
    'beauty', 'makeup', 'skincare', 'tutorial',
    'gaming', 'game', 'gamer', 'gameplay',
    'love', 'couple', 'relationship', 'romantic',
    'life', 'lifestyle', 'daily', 'vlog'
];

// Load configuration
function loadConfig() {
    try {
        config = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
    } catch (e) {
        console.error('Failed to load config:', e);
        config = { accounts: [], proxies: [], proxy_enabled: false, settings: {} };
    }
}

// Save configuration
function saveConfig() {
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
}

// Get next account (rotation)
function getNextAccount() {
    if (!config.accounts || config.accounts.length === 0) {
        return null;
    }
    
    const account = config.accounts[currentAccountIndex];
    currentAccountIndex = (currentAccountIndex + 1) % config.accounts.length;
    return account;
}

// Get random hashtag for variety
function getRandomHashtag() {
    return TRENDING_HASHTAGS[Math.floor(Math.random() * TRENDING_HASHTAGS.length)];
}

// Get Instagram client with session
async function getClient(username, password) {
    const ig = new IgApiClient();
    
    // Setup device
    ig.state.generateDevice(username);
    
    // Load proxy if enabled
    if (config.proxy_enabled && config.proxies && config.proxies.length > 0) {
        const proxy = config.proxies[Math.floor(Math.random() * config.proxies.length)];
        if (proxy.url) {
            console.log(`Using proxy: ${proxy.url}`);
        }
    }
    
    try {
        // Try to load session
        const sessionFile = path.join(SESSION_DIR, `${username}.json`);
        if (fs.existsSync(sessionFile)) {
            const session = JSON.parse(fs.readFileSync(sessionFile, 'utf8'));
            await ig.state.deserialize(session);
            console.log(`Loaded session for ${username}`);
        } else {
            // Login
            await ig.account.login(username, password);
            
            // Save session
            const state = await ig.state.serialize();
            fs.writeFileSync(sessionFile, JSON.stringify(state));
            console.log(`New session created for ${username}`);
        }
        
        return ig;
    } catch (error) {
        console.error(`Login failed for ${username}:`, error.message);
        throw error;
    }
}

// Download video from URL
async function downloadVideo(url, filename) {
    try {
        const response = await axios({
            method: 'GET',
            url: url,
            responseType: 'stream',
            timeout: 30000
        });
        
        const writer = fs.createWriteStream(path.join(VIDEO_DIR, filename));
        response.data.pipe(writer);
        
        return new Promise((resolve, reject) => {
            writer.on('finish', resolve);
            writer.on('error', reject);
        });
    } catch (error) {
        console.error(`Download failed for ${filename}:`, error.message);
        throw error;
    }
}

// Fetch reels from multiple sources for variety
async function downloadMixedReels() {
    const account = getNextAccount();
    if (!account) {
        console.log('No accounts configured');
        return 0;
    }
    
    try {
        console.log(`Using account: ${account.username}`);
        const ig = await getClient(account.username, account.password);
        
        let downloaded = 0;
        const maxCache = config.settings.max_cache || 100;
        
        // Strategy: Mix from different sources
        const sources = [
            'explore',    // Explore page (trending)
            'timeline',   // Timeline (following)
            'hashtag'     // Random hashtag
        ];
        
        // Randomly pick a source for variety
        const source = sources[Math.floor(Math.random() * sources.length)];
        console.log(`Fetching from: ${source}`);
        
        let items = [];
        
        if (source === 'explore') {
            // Get from explore page (most viral/trending)
            const exploreFeed = ig.feed.topicalExplore();
            const exploreItems = await exploreFeed.items();
            items = exploreItems.slice(0, 30);
            console.log('Fetching from EXPLORE (trending across all categories)');
            
        } else if (source === 'timeline') {
            // Get from timeline
            const timelineFeed = ig.feed.timeline();
            const timelineItems = await timelineFeed.items();
            items = timelineItems.slice(0, 30);
            console.log('Fetching from TIMELINE');
            
        } else if (source === 'hashtag') {
            // Get from random hashtag
            const hashtag = getRandomHashtag();
            console.log(`Fetching from hashtag: #${hashtag}`);
            const hashtagFeed = ig.feed.tag(hashtag);
            const hashtagItems = await hashtagFeed.items();
            items = hashtagItems.slice(0, 30);
        }
        
        // Process items
        for (const item of items) {
            // Only process reels/videos
            if (item.media_type !== 2 || !item.video_versions) continue;
            
            // Get video URL (best quality)
            const videoUrl = item.video_versions[0].url;
            const videoId = item.id.split('_')[0];
            const filename = `${videoId}.mp4`;
            const filepath = path.join(VIDEO_DIR, filename);
            
            // Skip if already downloaded
            if (fs.existsSync(filepath)) {
                continue;
            }
            
            // Download
            console.log(`Downloading: ${filename} from ${source}`);
            await downloadVideo(videoUrl, filename);
            downloaded++;
            
            // Stop if cache is full
            const videoCount = fs.readdirSync(VIDEO_DIR).filter(f => f.endsWith('.mp4')).length;
            
            if (videoCount >= maxCache) {
                console.log('Cache full, stopping');
                break;
            }
            
            // Small delay between downloads
            await new Promise(resolve => setTimeout(resolve, 2000));
        }
        
        console.log(`Downloaded ${downloaded} new reels from ${source}`);
        return downloaded;
        
    } catch (error) {
        console.error('Download error:', error.message);
        return 0;
    }
}

// Clean up old videos
function cleanupOldVideos() {
    try {
        const videos = fs.readdirSync(VIDEO_DIR)
            .filter(f => f.endsWith('.mp4'))
            .map(f => ({
                name: f,
                path: path.join(VIDEO_DIR, f),
                mtime: fs.statSync(path.join(VIDEO_DIR, f)).mtime
            }))
            .sort((a, b) => b.mtime - a.mtime);
        
        const maxAge = (config.settings.auto_delete_minutes || 10) * 60 * 1000;
        const now = Date.now();
        
        let deleted = 0;
        for (const video of videos) {
            const age = now - video.mtime.getTime();
            if (age > maxAge) {
                fs.unlinkSync(video.path);
                deleted++;
            }
        }
        
        if (deleted > 0) {
            console.log(`Cleaned up ${deleted} old videos`);
        }
    } catch (error) {
        console.error('Cleanup error:', error.message);
    }
}

// Main download loop
async function mainLoop() {
    console.log('🎭 Mixed Content Downloader Started');
    console.log('📱 Will fetch from: Explore, Timeline, and Trending Hashtags');
    isRunning = true;
    
    while (isRunning) {
        try {
            loadConfig();
            
            // Check cache size
            const videoCount = fs.readdirSync(VIDEO_DIR).filter(f => f.endsWith('.mp4')).length;
            const minCache = config.settings.min_cache || 50;
            
            console.log(`Current cache: ${videoCount} videos (minimum: ${minCache})`);
            
            // Download if below minimum
            if (videoCount < minCache) {
                console.log('Cache below minimum, downloading mixed content...');
                await downloadMixedReels();
            } else {
                console.log('Cache OK, waiting...');
            }
            
            // Cleanup old videos
            cleanupOldVideos();
            
            // Wait before next check
            const interval = (config.settings.download_interval_seconds || 60) * 1000;
            await new Promise(resolve => setTimeout(resolve, interval));
            
        } catch (error) {
            console.error('Main loop error:', error.message);
            await new Promise(resolve => setTimeout(resolve, 10000));
        }
    }
}

// Start downloader
if (require.main === module) {
    // Ensure directories exist
    fs.ensureDirSync(VIDEO_DIR);
    fs.ensureDirSync(SESSION_DIR);
    
    console.log('🎬 Instagram Reels Downloader - MIXED CONTENT');
    console.log('📱 Downloading from all categories: funny, dance, food, tech, pets, and more!');
    console.log('Press Ctrl+C to stop');
    
    mainLoop().catch(console.error);
    
    // Graceful shutdown
    process.on('SIGINT', () => {
        console.log('\nStopping downloader...');
        isRunning = false;
        process.exit(0);
    });
}

module.exports = { downloadMixedReels, cleanupOldVideos };
